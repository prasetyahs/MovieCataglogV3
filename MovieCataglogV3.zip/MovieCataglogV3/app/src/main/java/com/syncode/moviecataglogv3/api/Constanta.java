package com.syncode.moviecataglogv3.api;

public class Constanta {
    final static String BASE_URL = "https://api.themoviedb.org/";
    public final static String API_KEY = "3f409df90d09bb04f75d97b5b22491d1";
    public final static String BASE_URL_IMG = "https://image.tmdb.org/t/p/w500";
}
